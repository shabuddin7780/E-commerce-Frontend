import { ReactNode } from 'react';
import Header from './Header';
import Footer from './Footer';
import MiniCart from '../cart/MiniCart';
import { useCart } from '../../contexts/CartContext';

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const { isOpen, closeCart } = useCart();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        {children}
      </main>
      <Footer />
      {isOpen && (
        <>
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-40" 
            onClick={closeCart}
          />
          <MiniCart />
        </>
      )}
    </div>
  );
};

export default Layout;