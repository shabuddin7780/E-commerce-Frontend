import { Facebook, Twitter, Instagram, Github as GitHub } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <h2 className="text-xl font-bold mb-4">Mellow</h2>
            <p className="text-gray-400 mb-4">
              Delivering quality products with a focus on customer satisfaction. Shop with confidence.
            </p>
            <div className="flex space-x-4">
              <SocialIcon icon={<Facebook size={20} />} />
              <SocialIcon icon={<Twitter size={20} />} />
              <SocialIcon icon={<Instagram size={20} />} />
              <SocialIcon icon={<GitHub size={20} />} />
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Shop</h3>
            <ul className="space-y-2">
              <FooterLink href="#" label="All Products" />
              <FooterLink href="#" label="Featured Items" />
              <FooterLink href="#" label="New Arrivals" />
              <FooterLink href="#" label="Special Offers" />
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Information</h3>
            <ul className="space-y-2">
              <FooterLink href="#" label="About Us" />
              <FooterLink href="#" label="Contact Us" />
              <FooterLink href="#" label="Privacy Policy" />
              <FooterLink href="#" label="Terms of Service" />
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Subscribe</h3>
            <p className="text-gray-400 mb-4">Get the latest updates and offers</p>
            <form className="mb-4">
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your Email" 
                  className="bg-gray-800 text-white px-4 py-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-600 rounded-l-md"
                />
                <button 
                  type="submit" 
                  className="bg-blue-600 px-4 py-2 text-white rounded-r-md hover:bg-blue-700 transition-colors"
                >
                  Sign Up
                </button>
              </div>
            </form>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Mellow. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

interface FooterLinkProps {
  href: string;
  label: string;
}

const FooterLink = ({ href, label }: FooterLinkProps) => (
  <li>
    <Link 
      to={href} 
      className="text-gray-400 hover:text-white transition-colors"
    >
      {label}
    </Link>
  </li>
);

interface SocialIconProps {
  icon: React.ReactNode;
}

const SocialIcon = ({ icon }: SocialIconProps) => (
  <a href="#" className="bg-gray-800 p-2 rounded-full hover:bg-blue-600 transition-colors">
    {icon}
  </a>
);

export default Footer;