import { useState } from 'react';
import { ShoppingCart, Star } from 'lucide-react';
import { Product } from '../../types';
import { useCart } from '../../contexts/CartContext';
import { formatPrice } from '../../utils/formatters';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { addToCart } = useCart();
  const [isHovered, setIsHovered] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  const handleAddToCart = () => {
    setIsAdding(true);
    addToCart(product);
    
    // Reset the animation after a short delay
    setTimeout(() => {
      setIsAdding(false);
    }, 500);
  };

  return (
    <div 
      className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-64 bg-gray-100">
        <img 
          src={product.image} 
          alt={product.title} 
          className={`w-full h-full object-contain p-6 transition-transform duration-500 ${isHovered ? 'scale-105' : 'scale-100'}`}
        />
        <div className="absolute top-2 right-2 flex items-center bg-white px-2 py-1 rounded shadow-sm">
          <Star className="text-yellow-400 fill-yellow-400 w-4 h-4 mr-1" />
          <span className="text-xs font-medium">{product.rating.rate}</span>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-medium text-gray-800 mb-2 line-clamp-2 h-12">{product.title}</h3>
        <p className="text-lg font-semibold text-gray-900 mb-4">{formatPrice(product.price)}</p>
        
        <button 
          onClick={handleAddToCart}
          className={`w-full py-2 rounded-md flex items-center justify-center transition-all ${
            isAdding 
              ? 'bg-green-500 text-white'
              : 'bg-blue-600 hover:bg-blue-700 text-white'
          }`}
          disabled={isAdding}
        >
          {isAdding ? (
            'Added!'
          ) : (
            <>
              <ShoppingCart size={18} className="mr-2" />
              Add to Cart
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default ProductCard;