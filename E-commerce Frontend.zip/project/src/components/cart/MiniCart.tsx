import { Link } from 'react-router-dom';
import { X, ShoppingBag } from 'lucide-react';
import { useCart } from '../../contexts/CartContext';
import { formatPrice } from '../../utils/formatters';

const MiniCart = () => {
  const { cart, closeCart, removeFromCart, subtotal } = useCart();

  return (
    <div className="fixed top-0 right-0 bottom-0 w-full md:w-96 bg-white shadow-xl z-50 transform transition-transform duration-300 ease-in-out animate-slideInRight">
      <div className="h-full flex flex-col">
        <div className="py-4 px-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold flex items-center">
            <ShoppingBag className="mr-2" size={20} />
            Your Cart
          </h2>
          <button 
            onClick={closeCart} 
            className="text-gray-500 hover:text-gray-700"
            aria-label="Close cart"
          >
            <X size={24} />
          </button>
        </div>

        <div className="flex-grow overflow-y-auto py-4 px-6">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <ShoppingBag size={64} className="text-gray-300 mb-4" />
              <p className="text-gray-500 mb-6">Your cart is empty</p>
              <Link 
                to="/products" 
                className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
                onClick={closeCart}
              >
                Shop Now
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map((item) => (
                <div key={item.id} className="flex items-center border-b border-gray-100 pb-4">
                  <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden flex-shrink-0 mr-4">
                    <img 
                      src={item.image} 
                      alt={item.title} 
                      className="w-full h-full object-contain p-2"
                    />
                  </div>
                  <div className="flex-grow">
                    <h3 className="font-medium text-sm line-clamp-2">{item.title}</h3>
                    <div className="flex items-center justify-between mt-2">
                      <p className="text-gray-600 text-sm">
                        {formatPrice(item.price)} x {item.quantity}
                      </p>
                      <button 
                        onClick={() => removeFromCart(item.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                        aria-label={`Remove ${item.title} from cart`}
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {cart.length > 0 && (
          <div className="border-t border-gray-200 py-4 px-6">
            <div className="flex justify-between mb-4">
              <span className="font-medium">Subtotal</span>
              <span className="font-semibold">{formatPrice(subtotal)}</span>
            </div>
            <p className="text-gray-500 text-sm mb-4">
              Shipping and taxes calculated at checkout
            </p>
            <div className="space-y-2">
              <Link
                to="/cart"
                className="block w-full bg-blue-600 text-white text-center py-3 rounded-md hover:bg-blue-700 transition-colors"
                onClick={closeCart}
              >
                View Cart
              </Link>
              <button
                className="block w-full bg-gray-900 text-white text-center py-3 rounded-md hover:bg-black transition-colors"
                onClick={() => alert('Checkout functionality would be implemented here')}
              >
                Checkout
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MiniCart;