import { useEffect, useState } from 'react';
import { ArrowRight, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { fetchProducts } from '../services/api';
import { Product } from '../types';
import ProductCard from '../components/ui/ProductCard';
import { formatPrice } from '../utils/formatters';

const Home = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true);
        const products = await fetchProducts();
        // Get 4 random products for the featured section
        const randomProducts = [...products]
          .sort(() => Math.random() - 0.5)
          .slice(0, 4);
        setFeaturedProducts(randomProducts);
      } catch (error) {
        console.error('Failed to load products:', error);
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, []);

  return (
    <div className="pt-16"> {/* Added padding top to account for fixed header */}
      {/* Hero Section */}
      <section className="relative bg-gray-100 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-transparent" />
        <div className="container mx-auto px-4 py-16 md:py-24 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 z-10 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Discover Quality <span className="text-blue-600">Products</span> For Your Lifestyle
            </h1>
            <p className="text-lg text-gray-600 mb-8 max-w-lg">
              Explore our curated collection of premium items designed to enhance your everyday experience.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/products"
                className="bg-blue-600 text-white px-8 py-3 rounded-md hover:bg-blue-700 transition-colors text-center sm:text-left"
              >
                Shop Now
              </Link>
              <Link 
                to="#featured"
                className="bg-white text-blue-600 border border-blue-600 px-8 py-3 rounded-md hover:bg-blue-50 transition-colors text-center sm:text-left"
              >
                Featured Items
              </Link>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center relative">
            <div className="w-80 h-80 rounded-full bg-blue-100 absolute animate-pulse-slow" />
            <img 
              src="https://images.pexels.com/photos/5868722/pexels-photo-5868722.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
              alt="Hero" 
              className="w-full max-w-lg rounded-lg shadow-2xl z-10 relative"
            />
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Shop by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <CategoryCard 
              title="Men's Clothing" 
              imageSrc="https://images.pexels.com/photos/1176618/pexels-photo-1176618.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
            />
            <CategoryCard 
              title="Women's Clothing" 
              imageSrc="https://images.pexels.com/photos/934070/pexels-photo-934070.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
            />
            <CategoryCard 
              title="Jewelry" 
              imageSrc="https://images.pexels.com/photos/12761864/pexels-photo-12761864.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
            />
            <CategoryCard 
              title="Electronics" 
              imageSrc="https://images.pexels.com/photos/3178938/pexels-photo-3178938.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
            />
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section id="featured" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">Featured Products</h2>
            <Link 
              to="/products" 
              className="text-blue-600 hover:text-blue-800 flex items-center font-medium"
            >
              View All <ArrowRight size={16} className="ml-1" />
            </Link>
          </div>
          
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-md p-4 animate-pulse">
                  <div className="w-full h-56 bg-gray-200 rounded-md mb-4" />
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-4" />
                  <div className="h-10 bg-gray-200 rounded" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {featuredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">What Our Customers Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <TestimonialCard 
              quote="The quality of their products exceeded my expectations. Definitely coming back for more!"
              author="Sarah Johnson"
              rating={5}
            />
            <TestimonialCard 
              quote="Fast shipping and excellent customer service. The attention to detail is impressive."
              author="Michael Chen"
              rating={5}
            />
            <TestimonialCard 
              quote="Their products have become an essential part of my daily routine. Highly recommended!"
              author="Emily Rodriguez"
              rating={4}
            />
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Join Our Newsletter</h2>
          <p className="text-blue-100 mb-8 max-w-xl mx-auto">
            Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.
          </p>
          <div className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-4">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="flex-grow px-4 py-3 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 text-gray-900"
              />
              <button className="bg-gray-900 hover:bg-black text-white px-6 py-3 rounded-md transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

interface CategoryCardProps {
  title: string;
  imageSrc: string;
}

const CategoryCard = ({ title, imageSrc }: CategoryCardProps) => {
  return (
    <div className="group relative overflow-hidden rounded-lg shadow-md h-48 bg-gray-200">
      <img 
        src={imageSrc} 
        alt={title} 
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
        <h3 className="text-white font-medium p-4 w-full">{title}</h3>
      </div>
      <Link to="/products" className="absolute inset-0" aria-label={`Browse ${title}`} />
    </div>
  );
};

interface TestimonialCardProps {
  quote: string;
  author: string;
  rating: number;
}

const TestimonialCard = ({ quote, author, rating }: TestimonialCardProps) => {
  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
      <div className="flex mb-4">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i} 
            size={18} 
            className={i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"} 
          />
        ))}
      </div>
      <p className="text-gray-600 mb-4 italic">"{quote}"</p>
      <p className="font-medium">{author}</p>
    </div>
  );
};

export default Home;