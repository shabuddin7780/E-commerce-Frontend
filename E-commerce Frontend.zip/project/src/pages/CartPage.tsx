import { Link } from 'react-router-dom';
import { ShoppingBag, X, Plus, Minus, ArrowLeft } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { formatPrice } from '../utils/formatters';

const CartPage = () => {
  const { cart, updateQuantity, removeFromCart, subtotal, clearCart } = useCart();
  
  const shipping = subtotal > 0 ? 10 : 0;
  const total = subtotal + shipping;

  if (cart.length === 0) {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="container mx-auto px-4 py-16 flex flex-col items-center justify-center">
          <ShoppingBag size={80} className="text-gray-300 mb-6" />
          <h1 className="text-3xl font-bold mb-2">Your Cart is Empty</h1>
          <p className="text-gray-600 mb-8 text-center max-w-md">
            Looks like you haven't added anything to your cart yet.
          </p>
          <Link 
            to="/products" 
            className="bg-blue-600 text-white px-8 py-3 rounded-md hover:bg-blue-700 transition-colors flex items-center"
          >
            <ArrowLeft size={18} className="mr-2" /> Continue Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
        
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Cart Items */}
          <div className="lg:w-2/3">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <div className="hidden sm:grid sm:grid-cols-12 gap-4 mb-4 text-sm font-medium text-gray-500">
                  <div className="sm:col-span-6">Product</div>
                  <div className="sm:col-span-2 text-center">Price</div>
                  <div className="sm:col-span-2 text-center">Quantity</div>
                  <div className="sm:col-span-2 text-center">Total</div>
                </div>
                
                <div className="divide-y divide-gray-200">
                  {cart.map((item) => (
                    <div key={item.id} className="py-6 sm:grid sm:grid-cols-12 sm:gap-4">
                      {/* Product Info */}
                      <div className="sm:col-span-6 flex mb-4 sm:mb-0">
                        <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden flex-shrink-0">
                          <img 
                            src={item.image} 
                            alt={item.title} 
                            className="w-full h-full object-contain p-2"
                          />
                        </div>
                        <div className="ml-4 flex flex-col justify-between">
                          <h3 className="font-medium text-sm line-clamp-2">{item.title}</h3>
                          <button 
                            onClick={() => removeFromCart(item.id)}
                            className="text-gray-500 hover:text-red-500 text-sm flex items-center w-fit transition-colors"
                          >
                            <X size={14} className="mr-1" /> Remove
                          </button>
                        </div>
                      </div>
                      
                      {/* Price */}
                      <div className="sm:col-span-2 flex items-center justify-between sm:justify-center mb-4 sm:mb-0">
                        <span className="sm:hidden text-gray-500">Price:</span>
                        <span>{formatPrice(item.price)}</span>
                      </div>
                      
                      {/* Quantity */}
                      <div className="sm:col-span-2 flex items-center justify-between sm:justify-center mb-4 sm:mb-0">
                        <span className="sm:hidden text-gray-500">Quantity:</span>
                        <div className="flex items-center border border-gray-300 rounded-md">
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="px-2 py-1 text-gray-600 hover:bg-gray-100 rounded-l-md transition-colors"
                            disabled={item.quantity <= 1}
                            aria-label="Decrease quantity"
                          >
                            <Minus size={16} />
                          </button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="px-2 py-1 text-gray-600 hover:bg-gray-100 rounded-r-md transition-colors"
                            aria-label="Increase quantity"
                          >
                            <Plus size={16} />
                          </button>
                        </div>
                      </div>
                      
                      {/* Total */}
                      <div className="sm:col-span-2 flex items-center justify-between sm:justify-center">
                        <span className="sm:hidden text-gray-500">Total:</span>
                        <span className="font-medium">{formatPrice(item.price * item.quantity)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="px-6 py-4 bg-gray-50 flex justify-between items-center">
                <Link 
                  to="/products" 
                  className="text-blue-600 hover:text-blue-800 flex items-center"
                >
                  <ArrowLeft size={18} className="mr-1" /> Continue Shopping
                </Link>
                <button 
                  onClick={clearCart}
                  className="text-red-500 hover:text-red-700 transition-colors"
                >
                  Clear Cart
                </button>
              </div>
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>{formatPrice(shipping)}</span>
                </div>
                <div className="border-t pt-4 flex justify-between font-semibold">
                  <span>Total</span>
                  <span>{formatPrice(total)}</span>
                </div>
              </div>
              
              <div className="space-y-4">
                <button 
                  className="w-full bg-blue-600 text-white py-3 rounded-md hover:bg-blue-700 transition-colors"
                  onClick={() => alert('Checkout functionality would be implemented here')}
                >
                  Proceed to Checkout
                </button>
                
                <div className="p-4 bg-gray-50 rounded-md">
                  <p className="text-sm text-gray-600">
                    Free shipping on all orders over $100. Estimated delivery time: 3-5 business days.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;